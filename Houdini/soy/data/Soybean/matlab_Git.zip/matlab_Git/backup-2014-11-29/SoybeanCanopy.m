% ############### field diagram ####################
% 
% (0, CanopyRowNum*3, 0)                                (100, CanopyRowNum*3, 0)
%  * *  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
% (Xmin,Ymax,0.1)                                (Xmax,Ymax,0.1)
%        ------------[boundary for ray tracing]----------
%        |                                              |  
%        |                  //                          | 
%  * * * | * * *  * *  * * //*  * * [plants]* * * * * * | * * * * 
%        |                //                            | 
%        |               //                             | 
%        |              //[PAR sensor]                  | 
%        |             //                               | 
%  * * * | * * * * * *// * * * * * *   * * * * * * * *  | * * * * 
%        |           // (45 degree)                     | 
%        |   (sensorX,sensorY,sensorZ)                  |
%        ------------------------------------------------
% (Xmin,Ymin,0.1)                             (Xmax,Ymin,0.1)
%  * *  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
%(0,0,0)                                                       (100,0,0) 
%  

function SoybeanCanopy(intputMDfile, isview)

plantDis = 5.8;  % check with Becky.
CanopyRowNum = 4;  % build a canopy of 4 rows, in each row we have plantDis (5cm) distance plants

% used for ground triangle
Xmin = 12 + 0.1;
Xmax = 88 - 0.1;
Ymin = 19 + 0.1;
Ymax = 95 - 0.1;

% parameter for sensor setting
sensorX = 10;
sensorY = 10;
sensorZ = 5;

% import MD, measured data, file
md = importdata(intputMDfile);
md = md.data;

% convert unit from mm to cm
md(:,7:end) = md(:,7:end)/10;
md(:,3:6)   = md(:,3:6)/180*pi;

    % modified 2014-11-21, Qingfeng
    if sum( md(:,2)==0 ) == 2  % the C node has two leaves, we need to set this two leaves the same height. 
        md(3,7) = 0;           % let the second leaf internode equals to 0. 
        
    end

% adjust of input parameters, here
% TODO

%field parameter
bedLength = 100; %cm, use 76cm for simulation, from 12 ~ 88 for X
bedDistance = 38;%cm, for simulation, use from 19 ~ 95 for Y

%global veriables
N = 3;

PointsPlant = zeros(0,N);
FacetsPlant = zeros(0,N);
PointsCanopy = zeros(0,N);
FacetsCanopy = zeros(0,N);

CanopyIDS = zeros(0,7); %leafID leafLength Position SPAD Kt Kr NitrogenPerArea

%% multi plant
plantNumPerBed = bedLength/plantDis;

t=0;
for n=1:CanopyRowNum    % row number
    plantRotation = 1;
    for m=1:plantNumPerBed
        
        if plantRotation == 0
            plantRotation = 1;
        else
            plantRotation = 0;
        end
        
        [PointsPlant, FacetsPlant, PlantIDS] = soybeanPlant(md);
        CanopyIDS = [CanopyIDS; PlantIDS];
        
        t = t+1;
        
        X2 = PointsPlant(:,1);
        Y2 = PointsPlant(:,2);
        Z2 = PointsPlant(:,3);
        
        [theta, r, h] = cart2pol(X2, Y2, Z2);
        theta = theta + plantRotation * pi;
        [X2, Y2, Z2] = pol2cart(theta, r, h);
        
        X2 = X2 + (m-1)* plantDis;          % S-N direction, the plant build from S -> N (x-axis positive)
        Y2 = Y2 + (n-1)* bedDistance;       % W-E direction, the rows build from E -> W (y-axis positive)
        Z2 = Z2 + rand * 1;                 % 2cm diff among the plants
        

        PointsPlant2 = [X2,Y2,Z2];
        [row, col] = size(PointsCanopy);
        FacetsPlant2 = FacetsPlant + row;
        PointsCanopy = [PointsCanopy;PointsPlant2];
        FacetsCanopy = [FacetsCanopy;FacetsPlant2];
        
    end
end

% add ground
[groundPoints, groundFacets, groundIDS] = aGround(Xmin, Xmax, Ymin, Ymax);
[row, col] = size(PointsCanopy);
groundFacets = groundFacets + row;
PointsCanopy = [PointsCanopy; groundPoints];
FacetsCanopy = [FacetsCanopy; groundFacets];
CanopyIDS = [CanopyIDS; groundIDS];

% % add sensor
% [sensorPoints, sensorFacets, sensorIDS] = aPPFDsensor(sensorX, sensorY, sensorZ);
% [row, col] = size(PointsCanopy);
% sensorFacets = sensorFacets + row;
% PointsCanopy = [PointsCanopy; sensorPoints];
% FacetsCanopy = [FacetsCanopy; sensorFacets];
% CanopyIDS = [CanopyIDS; sensorIDS];

    
%convert to CM format
PointsA = PointsCanopy;
FacetsA = FacetsCanopy;

[row,col]=size(FacetsA)

metrix = zeros(row,16);
size(CanopyIDS)
metrix(:,10:16) = CanopyIDS;

for n=1:row
    metrix(n,1)= PointsA(FacetsA(n,1),1);
    metrix(n,2)= PointsA(FacetsA(n,1),2);
    metrix(n,3)= PointsA(FacetsA(n,1),3);
    metrix(n,4)= PointsA(FacetsA(n,2),1);
    metrix(n,5)= PointsA(FacetsA(n,2),2);
    metrix(n,6)= PointsA(FacetsA(n,2),3);
    metrix(n,7)= PointsA(FacetsA(n,3),1);
    metrix(n,8)= PointsA(FacetsA(n,3),2);
    metrix(n,9)= PointsA(FacetsA(n,3),3);

end


if (isview)
    %   dx = [PointsA(FacetsA(n,1),1),PointsA(FacetsA(n,2),1),PointsA(FacetsA(n,3),1)];
    %   dy = [PointsA(FacetsA(n,1),2),PointsA(FacetsA(n,2),2),PointsA(FacetsA(n,3),2)];
    %   dz = [PointsA(FacetsA(n,1),3),PointsA(FacetsA(n,2),3),PointsA(FacetsA(n,3),3)];
    
    %   patch(dx,dy,dz,rand,'FaceAlpha',0.6,'FaceColor','g');
    
    [row3,col3] = size(metrix);
    
    for i=1:row3
        va(i,1)=i;
        va(i,2)=row3+i;
        va(i,3)=2*row3+i;
    end
    color1 = zeros(row3,3);
%     color1(:,1) = 34;
%     color1(:,2) = 139;
%     color1(:,3) = 34;
 %  [ 34,139,34 ] ɭ����
    color1(:,1) = 34/255;
    color1(:,2) = 139/255;
    color1(:,3) = 34/255;
    figure;
    trisurf(va,metrix(:,[1,4,7]),metrix(:,[2,5,8]),metrix(:,[3,6,9]),metrix(:,[3,6,9])); %,'FaceAlpha',0.7,'EdgeColor','interp','LineWidth',0.5);
    axis equal;
    
%  view(-15,20)
    %colormapeditor

    view (50,30);
end


file = intputMDfile;
file = strcat(file,'-CM.txt');
dlmwrite(file,metrix,'delimiter', '\t');
%LeafMatrix = metrix;

end


